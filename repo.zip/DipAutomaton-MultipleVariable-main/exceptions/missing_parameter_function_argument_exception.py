class MissingParameterFunctionArgumentException(Exception):
    pass
