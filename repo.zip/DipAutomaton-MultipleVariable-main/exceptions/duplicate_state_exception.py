class DuplicateStateException(Exception):
    pass
