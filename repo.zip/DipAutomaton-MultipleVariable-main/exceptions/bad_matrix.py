class BadMatrixException(Exception):
    pass
