class UnableToProcess(Exception):
    pass
