class NoGotoException(Exception):
    pass
