class VariableUndefinedException(Exception):
    pass
